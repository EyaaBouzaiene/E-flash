/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
//import org.controlsfx.control.Rating;
import utils.MyDB;
import model.Rating;

/**
 * FXML Controller class
 *
 * @author 21627
 */
public class RateController implements Initializable {
  Connection connexion =MyDB.getInstance().getConnexion();
    Statement stm;
    @FXML
    private ComboBox<String> combo_email;
    @FXML
    private Button rateLivreur;
    @FXML
    private BarChart<?, ?> ratebar;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         try {
            stm = connexion.createStatement();
       
             String req1 = "SELECT email FROM  user where role='livreur' ";
            
            PreparedStatement statement1=connexion.prepareStatement(req1) ;
            ResultSet rst1 = statement1.executeQuery();
            ObservableList<String> list1 = FXCollections.observableArrayList();
             while (rst1.next()) {
           list1.add(rst1.getString("email"));
            combo_email.setItems(list1);
            }
            
            
             } catch (SQLException ex) {
            Logger.getLogger(livraisonController.class.getName()).log(Level.SEVERE, null, ex);
        }
        // TODO
    }    

    @FXML
    private void rating(ActionEvent event) throws SQLException {
         String v2 = combo_email.getSelectionModel().getSelectedItem();
         int idl=getidLivreur(v2);
         System.out.println(idl);
         Rating r =new Rating(idl, idl);
    }
    void addRating(Rating r) throws SQLException
    {
        String req = "INSERT INTO `rating` (`rating`, `idLivreur`) VALUES ( '"
                + r.getRating()+ "', '" + r.getIdLivreur()+ "') ";
        stm = connexion.createStatement();
        stm.executeUpdate(req);
    }
    int getidLivreur(String v) throws SQLException
    {
        String req = "select id from user where  email='"+v+"'";
        stm = connexion.createStatement();
        ResultSet rs =stm.executeQuery(req);
        rs.last();
        int i = rs.getInt("id");
        return i ;
    }
    
}
