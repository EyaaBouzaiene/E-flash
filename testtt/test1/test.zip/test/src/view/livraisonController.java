/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Livraison;
import service.LivraisonService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import utils.MyDB;


/**
 *
 * @author 21627
 */
public class livraisonController implements Initializable {
    LivraisonService L = new LivraisonService();
     Connection connexion =MyDB.getInstance().getConnexion();
    Statement stm;
    private Label label;
    @FXML
    private Button boutton_mail;
    @FXML
    private Button exit;
    @FXML
    private TableColumn<Livraison, Integer> col_id;
    @FXML
    private RadioButton sortprix;
    @FXML
    private RadioButton sortville;
    @FXML
    private Button boutton_stat;
    @FXML
    private ComboBox<Integer> combo_cmd;
    @FXML
    private ComboBox<String> combo_Liv;
    @FXML
    private TextField txt_id;
    @FXML
    private Button refresh;
    @FXML
    private Button rating;
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    
    @FXML
    private TableColumn<Livraison, Integer> col_cmd;

    @FXML
    private TableColumn<Livraison, String> col_etat;

    @FXML
    private TableColumn<Livraison, Integer> col_livreur;

    @FXML
    private TableColumn<Livraison, Integer> col_prix;

    @FXML
    private TableColumn<Livraison, String> col_ville;

    @FXML
    private TableView<Livraison> table_livraison;
    ObservableList<Livraison> livraisons;
    ObservableList<Livraison> ListeL;
    @FXML
    private TextField txt_cmd;

    @FXML
    private TextField txt_etat;

    @FXML
    private TextField txt_liv;

    @FXML
    private TextField txt_prix;

    @FXML
    private TextField txt_ville;
    @FXML
    private TextField txt_search;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
           
        try {
            // TODO
            
            loadData();
        } catch (SQLException ex) {
            Logger.getLogger(livraisonController.class.getName()).log(Level.SEVERE, null, ex);
        }
        Statement stm;
        
        
        try {
            stm = connexion.createStatement();
       
        
             String req = "SELECT refcmd FROM  commande";
             
            
            PreparedStatement statement=connexion.prepareStatement(req) ;
            
            ResultSet rst = statement.executeQuery();
          
            ObservableList<Integer> list = FXCollections.observableArrayList();
            
            while (rst.next()) {
            list.add(rst.getInt("refcmd"));
            combo_cmd.setItems(list);
        
            }
            
            
             } catch (SQLException ex) {
            Logger.getLogger(livraisonController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            stm = connexion.createStatement();
       
             String req1 = "SELECT email FROM  user where role='livreur' ";
            
            PreparedStatement statement1=connexion.prepareStatement(req1) ;
            ResultSet rst1 = statement1.executeQuery();
            ObservableList<String> list1 = FXCollections.observableArrayList();
             while (rst1.next()) {
           list1.add(rst1.getString("email"));
            combo_Liv.setItems(list1);
            }
            
            
             } catch (SQLException ex) {
            Logger.getLogger(livraisonController.class.getName()).log(Level.SEVERE, null, ex);
        }
             //statement.close();
        
           
           
        
        
        
        
      
    }    
    
     public void showLivraison(){
        
       
   
            try {
            
            table_livraison.setItems(L.afficherlivraison());
         } catch (SQLException ex) {
            Logger.getLogger(livraisonController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     public void showLivraisonSearch(){
        
       
   int m = Integer.parseInt(txt_search.getText());
        //ArrayList<Livraison> l = (ArrayList<Livraison>) L.RechercherlivraisonPrix_ID(m);
        //ObservableList<Livraison> obs = FXCollections.observableArrayList(l);
        //L.afficherlivraison(obs); 
           try {
            
            table_livraison.setItems( L.RechercherlivraisonPrix_ID(m));
         } catch (SQLException ex) {
            Logger.getLogger(livraisonController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
        
     
    private void loadData() throws SQLException {

        showLivraison();
        //String n= getnomLivreur();
            col_id.setCellValueFactory(new PropertyValueFactory<>("idLivraison"));
            col_cmd.setCellValueFactory(new PropertyValueFactory<>("idCommande"));
            col_livreur.setCellValueFactory(new PropertyValueFactory<>("idLivreur"));
       
            col_prix.setCellValueFactory(new PropertyValueFactory<>("prix"));
            col_ville.setCellValueFactory(new PropertyValueFactory<>("ville"));
            col_etat.setCellValueFactory(new PropertyValueFactory<>("etat"));
                   
    }
   int index=-1;
  
  
   

   

    @FXML
    private void modifierLivraison(ActionEvent event) {
        
        int v = Integer.parseInt(txt_id.getText());
       String v1 = txt_cmd.getText();
       String v2 = txt_liv.getText();
       String v3 = txt_prix.getText();
       String v4 = txt_ville.getText();
       String v5 = txt_etat.getText();
       LivraisonService sp= new LivraisonService();
        Livraison p = new Livraison(Integer.parseInt(v1),Integer.parseInt(v2),Integer.parseInt(v3),v4,v5);
        System.out.println(v);
        
        try {
            sp.modifierlivraison(p,v);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setContentText("Livraison is updated successfully!");
            alert.show();
            loadData();
            txt_cmd.setText("");
            txt_liv.setText("");
            txt_prix.setText("");
            txt_ville.setText("");
            txt_etat.setText("");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
       
    }

    @FXML
    private void tomail(ActionEvent event) throws IOException {
         Parent tableViewParent = FXMLLoader.load(getClass().getResource("/view/sendMail.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        //This line gets the Stage information
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
    }

    @FXML
    private void exit(ActionEvent event) {
        System.exit(0);
    }
    int getidLivreur(String v) throws SQLException
    {
        String req = "select id from user where  email='"+v+"'";
        stm = connexion.createStatement();
        ResultSet rs =stm.executeQuery(req);
        rs.last();
        int i = rs.getInt("id");
        return i ;
    }
    int getid() throws SQLException
    {
       String req = "select idLivreur from livreur ";
        stm = connexion.createStatement();
        ResultSet rs =stm.executeQuery(req);
        rs.last();
        int i = rs.getInt("idLivreur");
        return i;
    }

     String getnomLivreur() throws SQLException
    {
        int i =getid();
       String req = "select nom from user where  id='"+i+"'";
        stm = connexion.createStatement();
        ResultSet rs =stm.executeQuery(req);
        rs.last();
        String n = rs.getString("nom");
        return n ;
    }
       int getidbyref(int v) throws SQLException
    {
        String req = "select idCommande from commande where  refcmd='"+v+"'";
        stm = connexion.createStatement();
        ResultSet rs =stm.executeQuery(req);
        rs.last();
        int i = rs.getInt("idCommande");
        return i ;
    }

    @FXML
    private void ajoutLivraison(ActionEvent event) {
       LivraisonService sp= new LivraisonService();
       int v1 = combo_cmd.getSelectionModel().getSelectedItem();
      String v2 = combo_Liv.getSelectionModel().getSelectedItem();
        
          System.out.println(v1);
           System.out.println(v2);
       
       
        
        
        try {
            int idl=getidLivreur(v2);
            System.out.println(idl);
             int id2=getidbyref(v1);
             Livraison p = new Livraison(id2,
                 idl,Integer.parseInt(txt_prix.getText()),
                txt_ville.getText(),txt_etat.getText());
            sp.ajouterlivraison(p);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setContentText("Livraison is added successfully!");
            alert.show();
            txt_cmd.setText("");
            txt_liv.setText("");
            txt_prix.setText("");
            txt_ville.setText("");
            txt_etat.setText("");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
    }

    @FXML
    private void suppLivraison(ActionEvent event) {
         LivraisonService sp= new LivraisonService();
       int v = Integer.parseInt(txt_id.getText());
        System.out.println(v);
          try {
         sp.supprimerlivraison(v);
         Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setContentText("Livraison is deleted successfully!");
            alert.show();
            loadData();
            txt_cmd.setText(null);
            txt_liv.setText(null);
            txt_prix.setText(null);
            txt_ville.setText(null);
            txt_etat.setText(null);
          }
         catch (SQLException ex) {
            Logger.getLogger(livraisonController.class.getName()).log(Level.SEVERE, null, ex);
            
        }
          
    }

    @FXML
    private void sortprix(ActionEvent event) throws SQLException {
        //table_livraison.getChildren().clear();
        sortprix.setSelected(false);
       
        table_livraison.setItems( L.Trierlivraison(1));
        
    }

    @FXML
    private void sortville(ActionEvent event) throws SQLException {
        sortprix.setSelected(false);
        table_livraison.setItems(L.Trierlivraison(2));
    }

    @FXML
    private void searchLivraison(KeyEvent event) throws SQLException {
      
           int m = Integer.parseInt(txt_search.getText());
      
           try {
            
            table_livraison.setItems( L.RechercherlivraisonPrix_ID(m));
         } catch (SQLException ex) {
            Logger.getLogger(livraisonController.class.getName()).log(Level.SEVERE, null, ex);
        }
            col_id.setCellValueFactory(new PropertyValueFactory<>("idLivraison"));
            col_cmd.setCellValueFactory(new PropertyValueFactory<>("idCommande"));
            col_livreur.setCellValueFactory(new PropertyValueFactory<>("idLivreur"));
            col_prix.setCellValueFactory(new PropertyValueFactory<>("prix"));
            col_ville.setCellValueFactory(new PropertyValueFactory<>("ville"));
            col_etat.setCellValueFactory(new PropertyValueFactory<>("etat"));
            //txt_search.setText("");
            
    }

    @FXML
    private void gostat(ActionEvent event) throws IOException {
         Parent tableViewParent = FXMLLoader.load(getClass().getResource("/view/StatLivreur.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        //This line gets the Stage information
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
    }

    @FXML
    private void selected(javafx.scene.input.MouseEvent event) {
         index = table_livraison.getSelectionModel().getSelectedIndex();
        if(index<= -1)
        {
            return;
        }
            txt_cmd.setText(col_cmd.getCellData(index).toString());
            txt_liv.setText(col_livreur.getCellData(index).toString());
            txt_id.setText(col_id.getCellData(index).toString());
            txt_prix.setText(col_prix.getCellData(index).toString());
            txt_ville.setText(col_ville.getCellData(index).toString());
            txt_etat.setText(col_etat.getCellData(index).toString());
    }

    @FXML
    private void refresh(ActionEvent event) throws SQLException {
        txt_search.setText(null);
        loadData();
    }

    @FXML
    private void torate(ActionEvent event) throws IOException {
         Parent tableViewParent = FXMLLoader.load(getClass().getResource("/view/Rate.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        //This line gets the Stage information
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
    }

}
